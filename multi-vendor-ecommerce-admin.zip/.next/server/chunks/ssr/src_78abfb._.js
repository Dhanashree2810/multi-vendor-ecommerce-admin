module.exports = {

"[project]/src/assets/images/seller.png [app-ssr] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/seller.dc06abb9.png");}}),
"[project]/src/assets/images/seller.png.mjs { IMAGE => \"[project]/src/assets/images/seller.png [app-ssr] (static)\" } [app-ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$ssr$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/seller.png [app-ssr] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$ssr$5d$__$28$static$29$__["default"],
    width: 400,
    height: 400,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AP///wD0+/wMrOLlWm68v6hlwMSund/jae35+hP///8AAPX8/AuC19yHM5qd8lZSRf9QWU7/MZOU92vO1Z/s+foUALXn6k8huMLwUZiR/66Pc/+riGv/XoZ7/xistfiV3OFxAHbT2ZMTtL7/ab61//HZs//21av/gral/xKjrP9QvsW7AHfU2ZMTtL7/Kbi+/8jZvv/a1LT/Naus/xCiq/9Qu8K6ALbo6046vcXvecbM/8TY1f+6yMX/dLjB/zastPiW1tpvAPb8/ArE4+Z/0tbZ7rbByP+dsb3/u8nS9LrX3Jju+PkTAP///wD9/f0J8PHyTc7W25q9ytKi5OntXfr7/A////8AaIG0wUEZD7UAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
}}),
"[project]/src/app/seller/dashboard/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Page)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$moment$2f$moment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/moment/moment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$apexcharts$2f$dist$2f$react$2d$apexcharts$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-apexcharts/dist/react-apexcharts.min.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$ssr$5d$__$28$static$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/seller.png.mjs { IMAGE => "[project]/src/assets/images/seller.png [app-ssr] (static)" } [app-ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/md/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa6/index.mjs [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
const dashboardDemoData = {
    "totalProduct": 27,
    "totalOrder": 4,
    "totalSeller": 2,
    "messages": [
        {
            "_id": "675d0bdbc12e898f62d9d42b",
            "senderName": "FlashFusion Finds",
            "senderId": "675bec5357ed9d277e55b7c3",
            "receverId": "",
            "message": "Hello,",
            "status": "unseen",
            "createdAt": "2024-12-14T04:38:51.813Z",
            "updatedAt": "2024-12-14T04:38:51.813Z",
            "__v": 0
        },
        {
            "_id": "675d0c16c12e898f62d9daeb",
            "senderName": "Admin Support",
            "senderId": "",
            "receverId": "675bec5357ed9d277e55b7c3",
            "message": "How can I help You?",
            "status": "unseen",
            "createdAt": "2024-12-14T04:39:50.194Z",
            "updatedAt": "2024-12-14T04:39:50.194Z",
            "__v": 0
        }
    ],
    "recentOrders": [
        {
            "_id": "675c386957ed9d277e55ba4c",
            "customerId": "675c381357ed9d277e55b9a4",
            "products": [
                {
                    "_id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 0,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-13T13:28:36.967Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 262,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Supriya",
                "address": "Nashik",
                "phone": "9985625987",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Nashik",
                "area": "Nashik"
            },
            "delivery_status": "cancelled",
            "date": "December 13, 2024 7:06 PM",
            "createdAt": "2024-12-13T13:36:41.217Z",
            "updatedAt": "2024-12-13T13:36:56.268Z",
            "__v": 0
        },
        {
            "_id": "675c38ce57ed9d277e55ba96",
            "customerId": "675c388c57ed9d277e55ba62",
            "products": [
                {
                    "_id": "675c364657ed9d277e55b96a",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Woven, Self Design Bollywood Cotton Silk Saree  (Green, Gold)",
                    "slug": "Woven,-Self-Design-Bollywood-Cotton-Silk-Saree--(Green,-Gold)",
                    "category": "Fashion",
                    "brand": "Fashion Club Collection",
                    "price": 459,
                    "stock": 5,
                    "discount": 81,
                    "description": "jacquard weaving border saree is made from heavy cotton silk fabric which is highlighted with beautiful Weaving work. Comes along unstitched jacquard blouse piece which you can customize as per your design/style. Occasion - You can wear this saree for festive, special occasions, ideal for any fashionista. Style it up - Look glamorous in this traditional saree Pair this saree with Ethnic Gold Jewellery, beautiful clutch to complete the look!!",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096453/products/ydavtepfxovndut6v7om.jpg"
                    ],
                    "rating": 0,
                    "createdAt": "2024-12-13T13:27:34.069Z",
                    "updatedAt": "2024-12-13T13:27:34.069Z",
                    "__v": 0,
                    "quantity": 2
                }
            ],
            "price": 196,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Dhanashree K",
                "address": "Pune",
                "phone": "9514786321",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Pune",
                "area": "Pune"
            },
            "delivery_status": "cancelled",
            "date": "December 13, 2024 7:08 PM",
            "createdAt": "2024-12-13T13:38:22.355Z",
            "updatedAt": "2024-12-13T13:38:37.377Z",
            "__v": 0
        },
        {
            "_id": "675d0a79c12e898f62d9d3f6",
            "customerId": "675c388c57ed9d277e55ba62",
            "products": [
                {
                    "_id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 5,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-14T04:24:49.301Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 262,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Dhanashree K",
                "address": "Pune",
                "phone": "9985625987",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Pune",
                "area": "Pune"
            },
            "delivery_status": "cancelled",
            "date": "December 14, 2024 10:02 AM",
            "createdAt": "2024-12-14T04:32:57.379Z",
            "updatedAt": "2024-12-14T04:33:12.514Z",
            "__v": 0
        },
        {
            "_id": "675d166ac12e898f62dda26b",
            "customerId": "675c381357ed9d277e55b9a4",
            "products": [
                {
                    "_id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 4,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-14T05:22:55.195Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 292,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Supriya",
                "address": "Nashik",
                "phone": "9514786321",
                "post": "422003",
                "province": "Velit voluptatem ob",
                "city": "Nashik",
                "area": "Nashik"
            },
            "delivery_status": "cancelled",
            "date": "December 14, 2024 10:53 AM",
            "createdAt": "2024-12-14T05:23:54.338Z",
            "updatedAt": "2024-12-14T05:24:09.363Z",
            "__v": 0
        }
    ],
    "totalSale": 0
};
const userinfo = {
    "_id": "675bec78a4489cd6293c8c40",
    "name": "admin",
    "email": "admin@gmail.com",
    "password": "$2b$10$Dwlkn8QCQPCP5OiYPqXnk.r7f/k1WR7dBKXYWrkZCR/lIDlXn73sq",
    "role": "admin",
    "image": "",
    "createdAt": "2024-12-13T08:11:07.185Z",
    "updatedAt": "2024-12-13T08:11:07.185Z",
    "__v": 0
};
function Page() {
    const [dashboardData, setDashboardData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(dashboardDemoData);
    const [userInfo, setUserInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(userinfo);
    // useEffect(() => {
    //   // Simulating an API call. Replace with your actual API.
    //   const fetchDashboardData = async () => {
    //     const response = await fetch('http://localhost:5000/api/admin/get-dashboard-data'); // Update with your actual endpoint
    //     const data = await response.json();
    //     console.log("data",data);
    //     setDashboardData(data.dashboard);
    //     setUserInfo(data.userInfo);
    //   };
    //   fetchDashboardData();
    // }, []);
    const chartState = {
        series: [
            {
                name: 'Orders',
                data: [
                    23,
                    34,
                    45,
                    56,
                    76,
                    34,
                    23,
                    76,
                    87,
                    78,
                    34,
                    45
                ]
            },
            {
                name: 'Revenue',
                data: [
                    67,
                    39,
                    45,
                    56,
                    90,
                    56,
                    23,
                    56,
                    87,
                    78,
                    67,
                    78
                ]
            },
            {
                name: 'Sales',
                data: [
                    34,
                    39,
                    56,
                    56,
                    80,
                    67,
                    23,
                    56,
                    98,
                    78,
                    45,
                    56
                ]
            }
        ],
        options: {
            colors: [
                '#181ee8',
                '#181ee8'
            ],
            plotOptions: {
                radius: 30
            },
            chart: {
                background: 'transparent',
                foreColor: '#d0d2d6'
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                curve: [
                    'smooth',
                    'straight',
                    'stepline'
                ],
                lineCap: 'butt',
                colors: '#f0f0f0',
                width: 0.5,
                dashArray: 0
            },
            xaxis: {
                categories: [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Oct',
                    'Nov',
                    'Dec'
                ]
            },
            legend: {
                position: 'top'
            },
            responsive: [
                {
                    breakpoint: 565,
                    options: {
                        plotOptions: {
                            bar: {
                                horizontal: true
                            }
                        },
                        chart: {
                            height: '550px'
                        }
                    }
                }
            ]
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-1 flex-col gap-4 p-4 pt-0 dark-light",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-h-[100vh] flex-1 rounded-xl  md:min-h-min",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-2 md:px-7 py-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center p-5 bg-red-100 rounded-md gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: " flex flex-row",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-3xl font-bold text-black",
                                                        children: "₹ 0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                        lineNumber: 307,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 306,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-md font-medium text-black",
                                                    children: "Total Sales"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 311,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 305,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-10 h-10 rounded-full bg-red-600 flex justify-center items-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MdCurrencyExchange"], {
                                                className: "text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 314,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 313,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 304,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center p-5 bg-pink-100 rounded-md gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-3xl font-bold text-black",
                                                    children: "27"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 320,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-md font-medium text-black",
                                                    children: "Products"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 324,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 319,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-10 h-10 rounded-full bg-pink-600 flex justify-center items-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MdProductionQuantityLimits"], {
                                                className: "text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 327,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 326,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 318,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center p-5 bg-green-100 rounded-md gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-3xl font-bold text-black",
                                                    children: "2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 333,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-md font-medium text-black",
                                                    children: "Orders"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 337,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 332,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-10 h-10 rounded-full bg-green-600 flex justify-center items-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaUsers"], {
                                                className: "text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 340,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 339,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 331,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center p-5 bg-blue-100 rounded-md gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-3xl font-bold text-black",
                                                    children: "4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 346,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-md font-medium text-black",
                                                    children: "Pending Orders"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 350,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 345,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-10 h-10 rounded-full bg-blue-600 flex justify-center items-center",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaCartShopping"], {
                                                className: "text-white"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 353,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 352,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 344,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                            lineNumber: 303,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap mt-7",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full lg:w-7/12 lg:pr-3",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 bg-[#EFEFEF] rounded-md ",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$apexcharts$2f$dist$2f$react$2d$apexcharts$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            options: {
                                                ...chartState.options,
                                                chart: {
                                                    ...chartState.options.chart
                                                },
                                                xaxis: {
                                                    ...chartState.options.xaxis,
                                                    labels: {
                                                        style: {
                                                            colors: '#000'
                                                        }
                                                    }
                                                },
                                                yaxis: {
                                                    labels: {
                                                        style: {
                                                            colors: '#000'
                                                        }
                                                    }
                                                },
                                                title: {
                                                    ...chartState.options.title,
                                                    style: {
                                                        color: '#000'
                                                    }
                                                }
                                            },
                                            series: chartState.series,
                                            type: "bar",
                                            height: 350
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                            lineNumber: 362,
                                            columnNumber: 1
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                        lineNumber: 361,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 360,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full lg:w-5/12 lg:pl-4 mt-6 lg:mt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-4 bg-[#EFEFEF]rounded-md",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "font-semibold text-lg text-white pb-3",
                                                children: "Recent Customer Message"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 399,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                                className: "relative border-l border-gray-300",
                                                children: dashboardData.messages.map((message, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "mb-3 ml-6",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "absolute -left-5 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    className: "rounded-full",
                                                                    src: message.senderId === userInfo?._id ? userInfo.image : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$ssr$5d$__$28$static$2922$__$7d$__$5b$app$2d$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                    alt: "User",
                                                                    width: 40,
                                                                    height: 40
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                    lineNumber: 404,
                                                                    columnNumber: 29
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 403,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-3 bg-gray-800 rounded-lg",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex justify-between items-center mb-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-sm text-white",
                                                                                children: message.senderName
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                                lineNumber: 414,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                                                                className: "text-xs text-gray-400",
                                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$moment$2f$moment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(message.createdAt).startOf('hour').fromNow()
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                                lineNumber: 415,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                        lineNumber: 413,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-xs text-gray-300",
                                                                        children: message.message
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                        lineNumber: 419,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 412,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, index, true, {
                                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                        lineNumber: 402,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 400,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                        lineNumber: 398,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 397,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                            lineNumber: 359,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 bg-[#EFEFEF] rounded-md mt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "font-semibold text-lg text-black pb-3",
                                    children: "Recent Orders"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 429,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-x-auto",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "w-full text-sm text-left text-white",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                className: "uppercase border-b border-gray-500",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "py-3 px-4",
                                                            children: "Order ID"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                            lineNumber: 434,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "py-3 px-4",
                                                            children: "Price"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                            lineNumber: 435,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "py-3 px-4",
                                                            children: "Payment Status"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                            lineNumber: 436,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "py-3 px-4",
                                                            children: "Order Status"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                            lineNumber: 437,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                            className: "py-3 px-4",
                                                            children: "Action"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                            lineNumber: 438,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                    lineNumber: 433,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 432,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                children: dashboardData.recentOrders.map((order, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-3 px-4",
                                                                children: [
                                                                    "#",
                                                                    order._id
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 444,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-3 px-4",
                                                                children: [
                                                                    "$",
                                                                    order.price
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 445,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-3 px-4",
                                                                children: order.payment_status
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 446,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-3 px-4",
                                                                children: order.delivery_status
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 447,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                className: "py-3 px-4",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/seller/dashboard/order/details/${order._id}`,
                                                                    className: "text-blue-400",
                                                                    children: "View"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                    lineNumber: 449,
                                                                    columnNumber: 29
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                                lineNumber: 448,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, index, true, {
                                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                        lineNumber: 443,
                                                        columnNumber: 25
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                                lineNumber: 441,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                        lineNumber: 431,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                                    lineNumber: 430,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/seller/dashboard/page.tsx",
                            lineNumber: 428,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/seller/dashboard/page.tsx",
                    lineNumber: 302,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/seller/dashboard/page.tsx",
                lineNumber: 301,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/seller/dashboard/page.tsx",
            lineNumber: 300,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/seller/dashboard/page.tsx",
        lineNumber: 299,
        columnNumber: 7
    }, this);
}
}}),
"[project]/src/app/seller/dashboard/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=src_78abfb._.js.map