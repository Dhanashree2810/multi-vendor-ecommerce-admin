(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_38143b._.js", {

"[project]/src/components/custom/Tooltipcustom.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const Tooltip = ({ message, children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative group",
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute   left-1/2 -translate-x-1/2 bottom-full mb-2 hidden group-hover:block bg-gray-800 text-white text-xs rounded-md py-1 px-2 whitespace-nowrap",
                children: [
                    message,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-3 h-3 bg-gray-800 absolute left-1/2 -translate-x-1/2 top-full rotate-45"
                    }, void 0, false, {
                        fileName: "[project]/src/components/custom/Tooltipcustom.tsx",
                        lineNumber: 14,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/custom/Tooltipcustom.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/custom/Tooltipcustom.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_c = Tooltip;
const __TURBOPACK__default__export__ = Tooltip;
var _c;
__turbopack_refresh__.register(_c, "Tooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/images/seller.png [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/seller.dc06abb9.png");}}),
"[project]/src/assets/images/seller.png.mjs { IMAGE => \"[project]/src/assets/images/seller.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/images/seller.png [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 400,
    height: 400,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR42gEIAff+AP///wD0+/wMrOLlWm68v6hlwMSund/jae35+hP///8AAPX8/AuC19yHM5qd8lZSRf9QWU7/MZOU92vO1Z/s+foUALXn6k8huMLwUZiR/66Pc/+riGv/XoZ7/xistfiV3OFxAHbT2ZMTtL7/ab61//HZs//21av/gral/xKjrP9QvsW7AHfU2ZMTtL7/Kbi+/8jZvv/a1LT/Naus/xCiq/9Qu8K6ALbo6046vcXvecbM/8TY1f+6yMX/dLjB/zastPiW1tpvAPb8/ArE4+Z/0tbZ7rbByP+dsb3/u8nS9LrX3Jju+PkTAP///wD9/f0J8PHyTc7W25q9ytKi5OntXfr7/A////8AaIG0wUEZD7UAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/pages/admin/AdminDashboard.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>AdminDashboard)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$custom$2f$Tooltipcustom$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/custom/Tooltipcustom.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$moment$2f$moment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/moment/moment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/images/seller.png.mjs { IMAGE => "[project]/src/assets/images/seller.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$echarts$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/echarts/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/api/api.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$echarts$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/echarts/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/inputtext/inputtext.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/button/button.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/md/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa6/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$toast$2f$toast$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/toast/toast.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/datatable/datatable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/primereact/column/column.esm.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const dashboardDemoData = {
    "totalProduct": 27,
    "totalOrder": 4,
    "totalSeller": 2,
    "messages": [
        {
            "id": "675d0bdbc12e898f62d9d42b",
            "senderName": "FlashFusion Finds",
            "senderId": "675bec5357ed9d277e55b7c3",
            "receverId": "",
            "message": "Hello,",
            "status": "unseen",
            "createdAt": "2024-12-14T04:38:51.813Z",
            "updatedAt": "2024-12-14T04:38:51.813Z",
            "__v": 0
        },
        {
            "id": "675d0c16c12e898f62d9daeb",
            "senderName": "Admin Support",
            "senderId": "",
            "receverId": "675bec5357ed9d277e55b7c3",
            "message": "How can I help You?",
            "status": "unseen",
            "createdAt": "2024-12-14T04:39:50.194Z",
            "updatedAt": "2024-12-14T04:39:50.194Z",
            "__v": 0
        }
    ],
    "recentOrders": [
        {
            "id": "675c386957ed9d277e55ba4c",
            "customerId": "675c381357ed9d277e55b9a4",
            "products": [
                {
                    "id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 0,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-13T13:28:36.967Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 262,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Supriya",
                "address": "Nashik",
                "phone": "9985625987",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Nashik",
                "area": "Nashik"
            },
            "delivery_status": "cancelled",
            "date": "December 13, 2024 7:06 PM",
            "createdAt": "2024-12-13T13:36:41.217Z",
            "updatedAt": "2024-12-13T13:36:56.268Z",
            "__v": 0
        },
        {
            "id": "675c38ce57ed9d277e55ba96",
            "customerId": "675c388c57ed9d277e55ba62",
            "products": [
                {
                    "id": "675c364657ed9d277e55b96a",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Woven, Self Design Bollywood Cotton Silk Saree  (Green, Gold)",
                    "slug": "Woven,-Self-Design-Bollywood-Cotton-Silk-Saree--(Green,-Gold)",
                    "category": "Fashion",
                    "brand": "Fashion Club Collection",
                    "price": 459,
                    "stock": 5,
                    "discount": 81,
                    "description": "jacquard weaving border saree is made from heavy cotton silk fabric which is highlighted with beautiful Weaving work. Comes along unstitched jacquard blouse piece which you can customize as per your design/style. Occasion - You can wear this saree for festive, special occasions, ideal for any fashionista. Style it up - Look glamorous in this traditional saree Pair this saree with Ethnic Gold Jewellery, beautiful clutch to complete the look!!",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096453/products/ydavtepfxovndut6v7om.jpg"
                    ],
                    "rating": 0,
                    "createdAt": "2024-12-13T13:27:34.069Z",
                    "updatedAt": "2024-12-13T13:27:34.069Z",
                    "__v": 0,
                    "quantity": 2
                }
            ],
            "price": 196,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Dhanashree K",
                "address": "Pune",
                "phone": "9514786321",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Pune",
                "area": "Pune"
            },
            "delivery_status": "cancelled",
            "date": "December 13, 2024 7:08 PM",
            "createdAt": "2024-12-13T13:38:22.355Z",
            "updatedAt": "2024-12-13T13:38:37.377Z",
            "__v": 0
        },
        {
            "id": "675d0a79c12e898f62d9d3f6",
            "customerId": "675c388c57ed9d277e55ba62",
            "products": [
                {
                    "id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 5,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-14T04:24:49.301Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 262,
            "payment_status": "unpaid",
            "shippingInfo": {
                "name": "Dhanashree K",
                "address": "Pune",
                "phone": "9985625987",
                "post": "422005",
                "province": "Velit voluptatem ob",
                "city": "Pune",
                "area": "Pune"
            },
            "delivery_status": "cancelled",
            "date": "December 14, 2024 10:02 AM",
            "createdAt": "2024-12-14T04:32:57.379Z",
            "updatedAt": "2024-12-14T04:33:12.514Z",
            "__v": 0
        },
        {
            "id": "675d166ac12e898f62dda26b",
            "customerId": "675c381357ed9d277e55b9a4",
            "products": [
                {
                    "id": "675c368457ed9d277e55b976",
                    "sellerId": "675bec5357ed9d277e55b7c3",
                    "name": "Women Chanderi Kurta Pant Dupatta Set",
                    "slug": "Women-Chanderi-Kurta-Pant-Dupatta-Set",
                    "category": "Fashion",
                    "brand": "DISHWA FASHION",
                    "price": 709,
                    "stock": 20,
                    "discount": 66,
                    "description": "Kurta Fabric: Chanderi Silk Bottomwear Fabric: Chanderi Silk Fabric: Chanderi Silk Sleeve Length: Three-Quarter Sleeves Set Type: Kurta With Dupatta And Bottomwear Bottom Type: Pants Pattern: Printed Sizes: S (Bust Size: 36 in, Shoulder Size: 14.5 in, Kurta Waist Size: 34 in, Kurta Hip Size: 40 in, Kurta Length Size: 42 in, Bottom Waist Size: 27 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XL (Bust Size: 42 in, Shoulder Size: 16 in, Kurta Waist Size: 40 in, Kurta Hip Size: 46 in, Kurta Length Size: 42 in, Bottom Waist Size: 32 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) L (Bust Size: 40 in, Shoulder Size: 15.5 in, Kurta Waist Size: 38 in, Kurta Hip Size: 44 in, Kurta Length Size: 42 in, Bottom Waist Size: 30 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) M (Bust Size: 38 in, Shoulder Size: 15 in, Kurta Waist Size: 36 in, Kurta Hip Size: 42 in, Kurta Length Size: 42 in, Bottom Waist Size: 28 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m) XXL (Bust Size: 44 in, Shoulder Size: 16.5 in, Kurta Waist Size: 42 in, Kurta Hip Size: 48 in, Kurta Length Size: 42 in, Bottom Waist Size: 34 in, Bottom Length Size: 37 in, Duppatta Length Size: 2.1 m)",
                    "shopName": "EasyShop",
                    "images": [
                        "http://res.cloudinary.com/dbxtifnah/image/upload/v1734096515/products/afontmzqrko2wewcy0pw.jpg"
                    ],
                    "rating": 4,
                    "createdAt": "2024-12-13T13:28:36.967Z",
                    "updatedAt": "2024-12-14T05:22:55.195Z",
                    "__v": 0,
                    "quantity": 1
                }
            ],
            "price": 292,
            "payment_status": "paid",
            "shippingInfo": {
                "name": "Supriya",
                "address": "Nashik",
                "phone": "9514786321",
                "post": "422003",
                "province": "Velit voluptatem ob",
                "city": "Nashik",
                "area": "Nashik"
            },
            "delivery_status": "cancelled",
            "date": "December 14, 2024 10:53 AM",
            "createdAt": "2024-12-14T05:23:54.338Z",
            "updatedAt": "2024-12-14T05:24:09.363Z",
            "__v": 0
        }
    ],
    "totalSale": 0
};
const userinfo = {
    "id": "675bec78a4489cd6293c8c40",
    "name": "admin",
    "email": "admin@gmail.com",
    "password": "$2b$10$Dwlkn8QCQPCP5OiYPqXnk.r7f/k1WR7dBKXYWrkZCR/lIDlXn73sq",
    "role": "admin",
    "image": "",
    "createdAt": "2024-12-13T08:11:07.185Z",
    "updatedAt": "2024-12-13T08:11:07.185Z",
    "__v": 0
};
function AdminDashboard() {
    _s();
    const [dashboardData, setDashboardData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(dashboardDemoData);
    const [userInfo, setUserInfo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(userinfo);
    const [filters, setFilters] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        global: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        },
        name: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        },
        price: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        },
        payment_status: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        },
        delivery_status: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        },
        id: {
            value: "",
            matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
        }
    });
    const [first, setFirst] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(5);
    const chartRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminDashboard.useEffect": ()=>{
            if (chartRef.current) {
                const chart = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$echarts$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.init(chartRef.current);
                const option = {
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'shadow'
                        }
                    },
                    legend: {
                        data: [
                            'Orders',
                            'Revenue',
                            'Sellers'
                        ]
                    },
                    xAxis: {
                        type: 'category',
                        data: [
                            'Jan',
                            'Feb',
                            'Mar',
                            'Apr',
                            'May',
                            'Jun',
                            'Jul',
                            'Aug',
                            'Sep',
                            'Oct',
                            'Nov',
                            'Dec'
                        ]
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [
                        {
                            name: 'Orders',
                            type: 'bar',
                            data: [
                                23,
                                34,
                                45,
                                56,
                                76,
                                34,
                                23,
                                76,
                                87,
                                78,
                                34,
                                45
                            ]
                        },
                        {
                            name: 'Revenue',
                            type: 'bar',
                            data: [
                                67,
                                39,
                                45,
                                56,
                                90,
                                56,
                                23,
                                56,
                                87,
                                78,
                                67,
                                78
                            ]
                        },
                        {
                            name: 'Sellers',
                            type: 'bar',
                            data: [
                                34,
                                39,
                                56,
                                56,
                                80,
                                67,
                                23,
                                56,
                                98,
                                78,
                                45,
                                56
                            ]
                        }
                    ]
                };
                chart.setOption(option);
                const handleResize = {
                    "AdminDashboard.useEffect.handleResize": ()=>{
                        chart.resize();
                    }
                }["AdminDashboard.useEffect.handleResize"];
                window.addEventListener('resize', handleResize);
                return ({
                    "AdminDashboard.useEffect": ()=>{
                        chart.dispose();
                        window.removeEventListener('resize', handleResize);
                    }
                })["AdminDashboard.useEffect"];
            }
        }
    }["AdminDashboard.useEffect"], []);
    const renderHeader = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col sm:flex-row justify-between items-center bg-[#EFEFEF] p-4 rounded-md border border-gray-300 shadow-sm",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold mb-2 sm:mb-0",
                    children: "Recent Orders"
                }, void 0, false, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 307,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "p-input-icon-left w-full sm:w-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                            className: "pi pi-search"
                        }, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 309,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$inputtext$2f$inputtext$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputText"], {
                            type: "search",
                            onInput: (e)=>setFilters({
                                    ...filters,
                                    global: {
                                        value: e.currentTarget.value,
                                        matchMode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$api$2f$api$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterMatchMode"].CONTAINS
                                    }
                                }),
                            placeholder: "Search Sellers",
                            className: "p-inputtext-sm h-10 w-full sm:w-[300px] p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0097A7]"
                        }, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 310,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 308,
                    columnNumber: 13
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
            lineNumber: 306,
            columnNumber: 9
        }, this);
    const onPageChange = (e)=>{
        setFirst(e.first);
        setRows(e.rows);
    };
    const actionTemplate = (rowData)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                href: `/admin/orders/${rowData.id}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$custom$2f$Tooltipcustom$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    message: "View",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$button$2f$button$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        className: "bg-transparent",
                        children: "View"
                    }, void 0, false, {
                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                        lineNumber: 334,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 333,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                lineNumber: 332,
                columnNumber: 13
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
            lineNumber: 331,
            columnNumber: 9
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white rounded-md border-gray-300 shadow-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8",
                    children: [
                        {
                            title: 'Total Sales',
                            value: dashboardData.totalSale,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdCurrencyExchange"], {}, void 0, false, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 347,
                                columnNumber: 87
                            }, this),
                            color: 'bg-red-100'
                        },
                        {
                            title: 'Products',
                            value: dashboardData.totalProduct,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$md$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MdProductionQuantityLimits"], {}, void 0, false, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 348,
                                columnNumber: 87
                            }, this),
                            color: 'bg-pink-100'
                        },
                        {
                            title: 'Sellers',
                            value: dashboardData.totalSeller,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaUsers"], {}, void 0, false, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 349,
                                columnNumber: 85
                            }, this),
                            color: 'bg-green-100'
                        },
                        {
                            title: 'Orders',
                            value: dashboardData.totalOrder,
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaCartShopping"], {}, void 0, false, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 350,
                                columnNumber: 83
                            }, this),
                            color: 'bg-blue-100'
                        }
                    ].map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `flex justify-between items-center p-5 ${item.color} rounded-lg shadow-md`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl sm:text-3xl font-bold",
                                            children: item.value
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                            lineNumber: 354,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm sm:text-md font-medium",
                                            children: item.title
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                            lineNumber: 355,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 353,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `w-10 h-10 rounded-full ${item.color.replace('100', '600')} flex justify-center items-center text-white`,
                                    children: item.icon
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 357,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 352,
                            columnNumber: 25
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 345,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white shadow-md rounded-lg p-4",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    ref: chartRef,
                                    style: {
                                        height: '400px'
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 367,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 366,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 365,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white shadow-md rounded-lg p-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-[#EFEFEF] p-2",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "font-semibold text-lg",
                                            children: "Recent Seller Messages"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                            lineNumber: 373,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                        lineNumber: 372,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "space-y-4",
                                        children: dashboardData.messages.map((message, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "flex items-start space-x-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            className: "w-10 h-10 rounded-full",
                                                            src: message.senderId === userInfo?.id ? userInfo.image : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$images$2f$seller$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                            alt: "User",
                                                            width: 40,
                                                            height: 40
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                            lineNumber: 379,
                                                            columnNumber: 45
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                        lineNumber: 378,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "p-3 bg-white rounded-lg",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex justify-between gap-10 items-center mb-1",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-sm font-semibold",
                                                                        children: message.senderName
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                                        lineNumber: 389,
                                                                        columnNumber: 49
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                                                        className: "text-xs text-gray-500 text-end",
                                                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$moment$2f$moment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(message.createdAt).fromNow()
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                                        lineNumber: 390,
                                                                        columnNumber: 49
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                                lineNumber: 388,
                                                                columnNumber: 45
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-gray-600",
                                                                children: message.message
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                                lineNumber: 394,
                                                                columnNumber: 45
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                        lineNumber: 387,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, index, true, {
                                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                                lineNumber: 377,
                                                columnNumber: 37
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                        lineNumber: 375,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                lineNumber: 371,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 370,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 364,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white shadow-md rounded-lg p-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$toast$2f$toast$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toast"], {}, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 404,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: renderHeader()
                        }, void 0, false, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 405,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$datatable$2f$datatable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DataTable"], {
                            value: dashboardData.recentOrders,
                            paginator: true,
                            rowsPerPageOptions: [
                                5,
                                10,
                                25,
                                50
                            ],
                            rows: rows,
                            first: first,
                            onPage: onPageChange,
                            filters: filters,
                            showGridlines: true,
                            emptyMessage: "No sellers found.",
                            className: "p-datatable-sm",
                            responsiveLayout: "scroll",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                    field: "id",
                                    header: "Order ID",
                                    headerStyle: {
                                        background: "#0097A7",
                                        color: "white"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 419,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                    field: "price",
                                    header: "Price",
                                    sortable: true,
                                    headerStyle: {
                                        background: "#0097A7",
                                        color: "white"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 420,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                    field: "payment_status",
                                    header: "Payment Status",
                                    sortable: true,
                                    headerStyle: {
                                        background: "#0097A7",
                                        color: "white"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 421,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                    field: "delivery_status",
                                    header: "Order Status",
                                    sortable: true,
                                    headerStyle: {
                                        background: "#0097A7",
                                        color: "white"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 422,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$primereact$2f$column$2f$column$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Column"], {
                                    header: "Actions",
                                    body: actionTemplate,
                                    headerStyle: {
                                        background: "#0097A7",
                                        color: "white"
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                                    lineNumber: 423,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                            lineNumber: 406,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
                    lineNumber: 403,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
            lineNumber: 344,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/pages/admin/AdminDashboard.tsx",
        lineNumber: 343,
        columnNumber: 9
    }, this);
}
_s(AdminDashboard, "njMr2zaRWb+5RM4L5fWyxOCxOhc=");
_c = AdminDashboard;
var _c;
__turbopack_refresh__.register(_c, "AdminDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/admin/dashboard/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_38143b._.js.map