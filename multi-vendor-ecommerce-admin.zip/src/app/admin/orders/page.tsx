import React from 'react'
import OrdersList from '@/app/pages/admin/OrdersList';


export default function Orderspage() {
  return (
    <div>
      <OrdersList/>
    </div>
  )
}
