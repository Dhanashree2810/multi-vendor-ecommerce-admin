import SellerRequest from '@/app/pages/admin/SellerRequest'
import React from 'react'

export default function page() {
  return (
    <div> 
      <SellerRequest/>
    </div>
  )
}
