import React from 'react'
import Category from '@/app/pages/admin/Category'


export default function page() {
  return (
    <div>
        <Category/>
    </div>
  )
}
