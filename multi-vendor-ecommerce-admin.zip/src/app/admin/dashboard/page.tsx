import AdminDashboard from '@/app/pages/admin/AdminDashboard'
import React from 'react'

export default function page() {
  return (
    <div>
      <AdminDashboard/>
    </div>
  )
}
