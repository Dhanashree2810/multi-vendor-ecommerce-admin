import React from 'react'
import DeactiveSellers from '@/app/pages/admin/DeactivateSellers'

export default function page() {
  return (
    <div>
      <DeactiveSellers/>
    </div>
  )
}
