import React from 'react'
import Sellers from '@/app/pages/admin/Sellers'

export default function page() {
  return (
    <div>
        <Sellers/>
    </div>
  )
}
