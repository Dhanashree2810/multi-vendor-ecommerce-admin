import PaymentRequest from '@/app/pages/admin/PaymentRequest'
import React from 'react'

export default function page() {
  return (
    <div>
      <PaymentRequest/>
    </div>
  )
}
