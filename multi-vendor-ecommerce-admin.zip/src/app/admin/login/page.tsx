import { LoginForm } from "@/app/pages/homes/LoginForm";


export default async function page() {

  return (
    <div>
      <LoginForm/>
    </div>
  );
}

