import React from 'react'
import ChatSeller from '@/app/pages/admin/ChatSeller'


export default function page() {
  return (
    <div>
      <ChatSeller/>
    </div>
  )
}
