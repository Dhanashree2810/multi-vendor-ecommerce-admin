import OrderDetails from '@/app/pages/seller/Allproducts/AllproductView'
import React from 'react'

export default function page() {
  return (
    <div>
     <OrderDetails/>
    </div>
  )
}
