import Allproduct from '@/app/pages/seller/Allproduct'
import React from 'react'

export default function page() {
  return (
    <div>
      <Allproduct/>
    </div>
  )
}
