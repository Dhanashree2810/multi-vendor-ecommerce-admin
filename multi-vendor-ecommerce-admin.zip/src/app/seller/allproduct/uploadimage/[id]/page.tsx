
"use client"
import AddBanner from '@/app/pages/seller/Allproducts/allproductBanner'
import React from 'react'

export default function page() {


  return (
    <div>
    <AddBanner />
    </div>
  )
}
