"use client"
import EditProduct from '@/app/pages/seller/Allproducts/allproductEdit'
import React from 'react'

export default function page() {
  return (
    <div>
        <EditProduct/>

    </div>
  )
}
