import Discountproduct from '@/app/pages/seller/Discountproduct'
import React from 'react'

export default function page() {
  return (
    <div>
      <Discountproduct/>
    </div>
  )
}
