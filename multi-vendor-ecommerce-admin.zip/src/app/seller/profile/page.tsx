import ProfileSettings from '@/app/pages/seller/Profile'
import React from 'react'

export default function page() {
  return (
    <div>
      <ProfileSettings/>
    </div>
  )
}
