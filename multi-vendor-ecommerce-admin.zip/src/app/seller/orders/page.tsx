import OrdersTable from '@/app/pages/seller/Ordes'
import React from 'react'

export default function page() {
  return (
    <div>
      <OrdersTable/>
    </div>
  )
}
