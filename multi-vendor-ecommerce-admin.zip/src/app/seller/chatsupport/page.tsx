import ChatBox from '@/app/pages/seller/Chatsupport'
import React from 'react'

export default function page() {
  return (
    <div>
      <ChatBox/>
    </div>
  )
}
