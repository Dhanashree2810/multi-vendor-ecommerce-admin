import AddProduct from '@/app/pages/seller/addproduct'
import React from 'react'

export default function page() {
  return (
    <div>
      <AddProduct/>
    </div>
  )
}
