import ChatBox from '@/app/pages/seller/Chatcustomer'
import React from 'react'

export default function page() {
  return (
    <div>
      <ChatBox/>
    </div>
  )
}
