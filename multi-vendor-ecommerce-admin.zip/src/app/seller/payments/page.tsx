import Payments from '@/app/pages/seller/Payments'
import React from 'react'

export default function page() {
  return (
    <div>
        <Payments/>
    </div>
  )
}
